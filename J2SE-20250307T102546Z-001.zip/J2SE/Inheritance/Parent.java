public class Parent{
  int a;
  float b;
  void Show(){
    System.out.println("b in super class:  " + b);
  }


}

