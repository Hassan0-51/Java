public class A{
  int a;
  int b;
  int c;

  A(int p, int q, int r){
    a=p;
    b=q;
    c=r;
  }
}


