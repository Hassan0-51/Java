public abstract class Myclass{

public abstract void display();

public abstract void displaySomething();

public void show()
{System.out.println("This method is declared in Abstract class");}

}

