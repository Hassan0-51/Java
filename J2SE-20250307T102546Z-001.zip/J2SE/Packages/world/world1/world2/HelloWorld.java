package world.world1.world2;

import java.util.*;


public class HelloWorld{

	public void show(){
	System.out.println("This is show method of HelloWorld Class");
		}

  public static void main(String[] args) {
     
HelloWorld obj = new HelloWorld();
obj.show();	
}
}
